print("tool")
