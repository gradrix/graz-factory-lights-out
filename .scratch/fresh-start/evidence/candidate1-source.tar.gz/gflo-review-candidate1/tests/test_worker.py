import tempfile
from pathlib import Path
import unittest

from gflo.worker import ModelWorker


class FakeSandbox:
    def cleanup(self, workspace):
        pass
    def execute(self, workspace, command, **kwargs):
        return {'exit_code': 0, 'output': 'app.py'}
    def verify(self, *args):
        return {'passed': False, 'checks': [{'output': 'expected value 2'}]}


class WorkerTests(unittest.TestCase):
    def test_tools_and_completion_leave_a_replayable_trace(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / 'workspace'
            workspace.mkdir()
            worker = ModelWorker({'endpoint': 'http://127.0.0.1:18000', 'model': 'test'}, FakeSandbox())
            messages = iter([
                {'role': 'assistant', 'content': None, 'tool_calls': [{'id': '1', 'type': 'function', 'function': {'name': 'run', 'arguments': '{"command":"ls"}'}}]},
                {'role': 'assistant', 'content': None, 'tool_calls': [{'id': '2', 'type': 'function', 'function': {'name': 'check', 'arguments': '{}'}}]},
                {'role': 'assistant', 'content': 'Done'}])
            worker.request = lambda *args, **kwargs: {'choices': [{'message': next(messages), 'finish_reason': 'stop'}]}
            result = worker(workspace, {'objective': 'Fix value', 'max_turns': 4, 'checks': []}, None, 1)
            self.assertEqual(result['turns'], 3)
            trace = workspace.parent / 'attempts/1/trajectory.jsonl'
            self.assertIn('expected value 2', trace.read_text())

    def test_remote_inference_and_redirects_are_not_implicitly_allowed(self):
        with self.assertRaisesRegex(ValueError, 'loopback'):
            ModelWorker({'endpoint': 'https://example.com', 'model': 'test'}, FakeSandbox())
