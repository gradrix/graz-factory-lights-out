# GFLO

A small local software factory: give it a repository, a task and executable acceptance checks. It edits an isolated copy, checks the result and repairs failures within a fixed budget. Your source repository stays unchanged. An accepted run produces a patch and its evidence.

**Initial scope:** bounded Python projects using locally installed dependencies. Large-project autonomy, automatic task decomposition and automatic merging are not implemented.

## Run on MONSTER-GAMING-PC

The prepared installation is `/home/gradrix/gflo-runtime`. The model and sandbox image are already on disk. Once installed, these commands need no Internet connection:

```sh
cd /home/gradrix/gflo-runtime
python3 -m gflo doctor
python3 examples/prepare.py .gflo/examples
python3 -m gflo run .gflo/examples/invoice/task.json
python3 -m gflo status
```

`prepare.py` creates new example repositories; it refuses to overwrite existing ones. Run the other examples with `inventory/task.json` and `log-summary/task.json`. Run one task at a time using the same state directory.

To use this checkout with the rig's model, see [local setup](docs/operations.md). Python 3.10+, Git and Docker are required. The runtime uses only Python's standard library; no agent subscription, hosted API or cloud fallback is involved.

## Bring a task

Commit the intended input in a clean Git repository. Create an acceptance directory outside the worker repository and a task JSON file:

```json
{
  "repo": "path/to/repository",
  "objective": "Describe the required behavior, compatibility and deliverables.",
  "acceptance": "acceptance",
  "checks": [["python", "-I", "/acceptance/check.py"]],
  "max_attempts": 3,
  "max_turns": 24
}
```

Paths are relative to the task file. Checks are argument lists, not shell expressions. They run in `/workspace` with the candidate and `/acceptance` mounted read-only. Use `/tmp` for test databases and other temporary output. Dependencies must already exist in the configured, pinned sandbox image.

Acceptance checks are trusted operator code. Make them test observable requirements and fail on missing tests, not just print a success message. The [examples](examples/) demonstrate behavior checks and a separate quality check requiring discoverable tests, documentation and removal of scratch files.

```sh
python3 -m gflo run task.json
python3 -m gflo status RUN_ID
python3 -m gflo resume RUN_ID
```

An interrupted attempt consumes its attempt allowance; resume keeps its files and passes interruption evidence to the next attempt. A saved completed verdict can be reconciled without repeating the worker. Exhausted runs stop; revise the task deliberately and start a new run. Modified accepted artifacts are reported as invalidated.

Exit codes: `0` accepted/read-only command success, `2` exhausted, `1` configuration/runtime failure, `130` interruption. Run ID and evidence directory print before execution; status works without the model.

## Inspect the result

`.gflo/runs/RUN_ID/` contains the frozen task, acceptance files, candidate workspace, per-attempt conversation and verification results, and `change.patch`. Acceptance means the configured checks passed for that candidate; it does not certify requirements the checks never exercised.

Review the patch before applying it to the source repository at the recorded base commit:

```sh
git -C /path/to/repository apply --check /absolute/path/to/change.patch
git -C /path/to/repository apply /absolute/path/to/change.patch
```

GFLO never pushes, merges or deploys generated changes. Full prompts and tool output are retained locally in run artifacts; treat them with the same privacy as the source code.

## Develop and extend

```sh
make test
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
make coverage
```

The tests include real offline Docker execution, so the pinned image must be installed. Development coverage tooling needs a one-time installation; the factory runtime does not.

The implementation has three responsibilities: [runner](gflo/runner.py) owns durable state and acceptance, [worker](gflo/worker.py) owns the model/tool conversation, and [sandbox](gflo/sandbox.py) executes commands and verification. [CLI](gflo/__main__.py) connects them. Start extension with a concrete task or a prepared image and new checks; add a new module only when a demonstrated responsibility needs one.

Read [architecture and limits](docs/architecture.md), [operations and rollback](docs/operations.md), and [pilot results](docs/pilot-results.md). The old design was archived before this reset; [archive receipt](.scratch/reset-archive.txt) and Git history retain it. It is not the new implementation roadmap.
