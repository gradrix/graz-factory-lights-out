# Architecture and limits

## One task through three responsibilities

The CLI snapshots a clean Git commit and operator-owned acceptance files. The runner records a task in SQLite, then invokes the worker. The worker gets two tools: a shell in an offline container and a request to run acceptance checks. A final verification runs independently of the worker's completion message.

```text
pending → running → verification → accepted
              ↑           │
              └─ repair ──┘
                 │
              exhausted

process interruption → interrupted → resume within original budget
accepted artifact changed → invalidated
```

SQLite stores run/attempt states; files store complete requests, outputs, checks and patches. An OS file lock serializes runs in one state directory. Each new attempt receives the objective and previous failure evidence, with the retained workspace. There is no accumulated conversation across attempts and no hidden context condensation. Oversized model requests fail visibly.

The worker cannot mount the controller database, private Git index, credentials or acceptance files. Its shell container has no network, a read-only root filesystem, a writable candidate mount, a bounded temporary filesystem, resource limits and a non-root user. Verification uses a fresh container with both mounts read-only. The runner cleans leftover containers for its workspace before reconciling a resumed run.

Generated code still runs in the same kernel through Docker. This is practical isolation for local coding, not a hardened hostile multi-tenant service. Tests can be incomplete or deceptive; operator-owned black-box checks and patch review remain necessary. The system does not infer the adequacy of a test suite from an exit code.

## Bounds

- Default three attempts; permitted range one to ten.
- Default 24 model turns per attempt; permitted range one to 100.
- Five identical tool requests stop an attempt's model loop.
- Model request timeout up to 300 seconds; worker stops scheduling turns after 30 minutes. An already-started command can finish after that scheduling deadline.
- Shell commands: 60 seconds. Each acceptance command: 120 seconds.
- Container: 1 GiB RAM, two CPUs, 128 processes, 128 MiB `/tmp`; shell output retains its final 16 KiB.
- No dependency downloads during runs. Shell containers use `--network none`, images use `--pull never`, and inference is restricted to loopback, directly or through an explicit SSH tunnel.

The filesystem is not quota-managed. Keep task inputs and generated output bounded and monitor disk space. The state directory lock does not serialize unrelated state directories or other clients of the GPU. A Windows/WSL shutdown stops the rig; Docker restart policy resumes serving when Docker starts again, but does not boot Windows or WSL.

## Extension seams

`Factory(state, worker, verifier, cleanup)` owns task transitions. The worker callable receives `(workspace, task, previous_evidence, attempt_number)` and returns a report. The verifier receives `(workspace, task, acceptance_directory)` and returns a boolean verdict plus check evidence. Cleanup terminates retained execution before observing a resumed candidate.

These callables also enable deterministic fault injection in tests. Production uses one implementation of each. Further stacks can supply a pinned local image and acceptance commands; shell tooling and the prompt currently assume a Python project. Symlink-containing input repositories and Git submodules are rejected explicitly.

Automatic planning/delegation is a later stage. First accumulate real-task completion, repair, interruption and regression evidence. SFLO inspired explicit acceptance/repair stages; Gas City inspired work state that survives disposable sessions. Neither is a runtime dependency. Historical source research remains in the reset archive.
