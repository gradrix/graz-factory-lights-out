# Pilot results

Qualification is in progress. The final report will distinguish each candidate and acceptance revision; exploratory results are retained rather than relabeled.

Initial invoice experiment passed functional acceptance after two attempts but failed the intended quality requirement: its regression methods lacked the `test_` prefix, and it left scratch CSVs. The original gate allowed zero discovered tests. This triggered a stricter example quality gate, a regression test with passing/rejecting controls, and another live qualification run.

The first inventory run passed behavior checks including concurrent reservations on its first attempt. It used the earlier quality contract and will be rerun against the stricter one.

Frozen runtime candidate 1 was independently checked. Early-crash recovery and accepted-artifact integrity defects were reproduced and repaired; orphan-container cleanup was moved before recovery observations. Final recheck and full results are linked here when complete.
